#! /bin/sh

update-rc.d -f RemoteKeypadDriver.sh remove

